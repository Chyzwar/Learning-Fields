
public class Main {

	public static void main(String[] args) {
		StudentManager sm = new StudentManager();
		sm.run();
	}
}
