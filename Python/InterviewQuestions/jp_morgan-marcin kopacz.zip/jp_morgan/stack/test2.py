from src.stack import Stack

stack = Stack()
stack.push(1)
stack.push(5)
print(str(stack))

stack.pop()
print(str(stack))
