from src.stack import Stack

stack = Stack()
stack.pop()
